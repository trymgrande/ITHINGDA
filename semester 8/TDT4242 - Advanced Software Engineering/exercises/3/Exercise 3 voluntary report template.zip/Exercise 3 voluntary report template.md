﻿**Voluntary Outline for Exercise 3**

**Group number:**

1. **Introduction**
- Summarize what you have done.

1. **Code review guideline**
- Present your code review guideline using guided words

1. **Code refactoring results**

- You can use the following table to fill the results. If you do not like using the table, you make your own format. 


|Bad code smell category|How is the code smell identified (code review or automatic analysis tools?)|Relate test scripts|Code before refactoring|Code after refactoring|
| :-: | :-: | :-: | :-: | :-: |
||||||

Link to your repository: <fill in here>
