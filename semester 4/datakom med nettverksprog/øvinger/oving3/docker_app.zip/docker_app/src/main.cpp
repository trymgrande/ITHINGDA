#include <iostream>
using namespace std;

int main()
{    

    cout << "You entered " << "lars css gud";    
    return 0;
}