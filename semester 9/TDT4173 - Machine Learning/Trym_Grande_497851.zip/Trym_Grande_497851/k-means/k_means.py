import numpy as np
import pandas as pd


# IMPORTANT: DO NOT USE ANY OTHER 3RD PARTY PACKAGES
# (math, random, collections, functools, etc. are perfectly fine)

class KMeans:

    def __init__(self, k=2):
        # NOTE: Feel free add any hyperparameters
        # (with defaults) as you see fit
        self.centroids = np.empty(k)
        self.k = k

    def fit(self, X):
        """
        Estimates parameters for the classifier

        Args:
            X (array<m,n>): a matrix of floats with 
                m rows (#samples) and n columns (#features)
        """        
        self.centroids = X.sample(n=self.k).values
        initial_centroids = self.centroids
        cluster = np.zeros(X.values.shape[0])
        while True:
            for i, row in enumerate(X.values):
                nearest_centroid = float('inf')
                for j, centroid in enumerate(self.centroids):
                    distance = calculate_distance(centroid, row)
                    if nearest_centroid > distance:
                        nearest_centroid = distance
                        cluster[i] = j
            new_centroids = pd.DataFrame(X.values).groupby(by=cluster).mean().values
            
            # check for centroid convergence
            if np.count_nonzero(self.centroids - new_centroids) == 0: break
            self.centroids = new_centroids
            """plt.figure(figsize=(5, 5))
            C = self.centroids
            _, ax = plt.subplots(figsize=(5, 5), dpi=100)
            sns.scatterplot(x='x0', y='x1', palette='tab10', data=X, ax=ax)
            sns.scatterplot(x=C[:, 0], y=C[:, 1], hue=range(self.k), palette='tab10', marker='*', s=250, edgecolor='black',
                            ax=ax)
            ax.legend().remove()"""
        return initial_centroids

    def predict(self, X):
        """
        Generates predictions

        Note: should be called after .fit()

        Args:
            X (array<m,n>): a matrix of floats with
                m rows (#samples) and n columns (#features)

        Returns:
            A length m integer array with cluster assignments
            for each point. E.g., if X is a 10xn matrix and
            there are 3 clusters, then a possible assignment
            could be: array([2, 0, 0, 1, 2, 1, 1, 0, 2, 2])
        """
        predictions = []
        for row in X.values:
            distances = []
            for i, centroid in enumerate(self.centroids):
                distances.append([euclidean_distance(row, centroid), i])
            predictions.append(min(range(len(distances)), key=distances.__getitem__))
        return predictions

    def get_centroids(self):
        """
        Returns the centroids found by the K-mean algorithm

        Example with m centroids in an n-dimensional space:
        >>> model.get_centroids()
        numpy.array([
            [x1_1, x1_2, ..., x1_n],
            [x2_1, x2_2, ..., x2_n],
                    .
                    .
                    .
            [xm_1, xm_2, ..., xm_n]
        ])
        """
        return self.centroids


# --- Some utility functions


def euclidean_distortion(X, z):
    """
    Computes the Euclidean K-means distortion

    Args:
        X (array<m,n>): m x n float matrix with datapoints
        z (array<m>): m-length integer vector of cluster assignments

    Returns:
        A scalar float with the raw distortion measure
    """
    X, z = np.asarray(X), np.asarray(z)
    assert len(X.shape) == 2
    assert len(z.shape) == 1
    assert X.shape[0] == z.shape[0]

    distortion = 0.0
    for c in np.unique(z):
        Xc = X[z == c]
        mu = Xc.mean(axis=0)
        distortion += ((Xc - mu) ** 2).sum()

    return distortion


def euclidean_distance(x, y):
    """
    Computes euclidean distance between two sets of points

    Note: by passing "y=0.0", it will compute the euclidean norm

    Args:
        x, y (array<...,n>): float tensors with pairs of
            n-dimensional points

    Returns:
        A float array of shape <...> with the pairwise distances
        of each x and y point
    """
    return np.linalg.norm(x - y, ord=2, axis=-1)


def cross_euclidean_distance(x, y=None):
    """
    Compute Euclidean distance between two sets of points

    Args:
        x (array<m,d>): float tensor with pairs of
            n-dimensional points.
        y (array<n,d>): float tensor with pairs of
            n-dimensional points. Uses y=x if y is not given.

    Returns:
        A float array of shape <m,n> with the euclidean distances
        from all the points in x to all the points in y
    """
    y = x if y is None else y
    assert len(x.shape) >= 2
    assert len(y.shape) >= 2
    return euclidean_distance(x[..., :, None, :], y[..., None, :, :])


def euclidean_silhouette(X, z):
    """
    Computes the average Silhouette Coefficient with euclidean distance

    More info:
        - https://www.sciencedirect.com/science/article/pii/0377042787901257
        - https://en.wikipedia.org/wiki/Silhouette_(clustering)

    Args:
        X (array<m,n>): m x n float matrix with datapoints
        z (array<m>): m-length integer vector of cluster assignments

    Returns:
        A scalar float with the silhouette score
    """
    X, z = np.asarray(X), np.asarray(z)
    assert len(X.shape) == 2
    assert len(z.shape) == 1
    assert X.shape[0] == z.shape[0]

    # find mean distances from each point to all other clusters
    clusters = np.unique(z)
    D = np.zeros((len(X), len(clusters)))
    for i, ca in enumerate(clusters):
        for j, cb in enumerate(clusters):
            in_cluster_a = z == ca
            in_cluster_b = z == cb
            d = cross_euclidean_distance(X[in_cluster_a], X[in_cluster_b])
            div = d.shape[1] - int(i == j)
            D[in_cluster_a, j] = d.sum(axis=1) / np.clip(div, 1, None)

    # intra distance
    a = D[np.arange(len(X)), z]
    # min inter distance
    infinite_mask = np.where(z[:, None] == clusters[None], np.inf, 0)
    b = (D + infinite_mask).min(axis=1)

    return np.mean((b - a) / np.maximum(a, b))

def normalize_data(data):
    return (data - data.min()) / (data.max() - data.min())

def calculate_distance(centroid, row):
    return np.sqrt((centroid[0] - row[0]) ** 2 + (centroid[1] - row[1]) ** 2)