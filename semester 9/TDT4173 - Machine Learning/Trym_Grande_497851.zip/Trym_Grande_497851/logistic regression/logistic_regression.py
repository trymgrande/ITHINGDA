
from matplotlib import pyplot as plt
import numpy as np 
import pandas as pd 

# IMPORTANT: DO NOT USE ANY OTHER 3RD PARTY PACKAGES
# (math, random, collections, functools, etc. are perfectly fine)

class LogisticRegression:
    
    def __init__(self, epochs=150, step_size_w=0.05, step_size_b=0.05, bias=0):
        self.epochs = epochs
        self.step_size_w = step_size_w
        self.step_size_b = step_size_b
        self.bias = bias
        self.train_accuracies = []
        self.losses = []
        self.weights = None

    def fit(self, X, y):
        """
        Estimates parameters for the classifier
        
        Args:
            X (array<m,n>): a matrix of floats with
                m rows (#samples) and n columns (#features)
            y (array<m>): a vector of floats containing 
                m binary 0.0/1.0 labels
        """
        self.weights = np.zeros(X.shape[1])

        for i in range(self.epochs):
            x_dot_weights = np.matmul(self.weights, X.transpose()) + self.bias
            pred = sigmoid(x_dot_weights)
            loss = binary_cross_entropy(y, pred)
            error_w, error_b = self.compute_gradients(X, y, pred)
            self.update_model_parameters(error_w, error_b)

            pred_to_class = np.array([1 if p > 0.5 else 0 for p in pred])
            self.train_accuracies.append(binary_accuracy(y, pred_to_class))
            self.losses.append(loss)

            if (i % (self.epochs / 10)) == 0:
                print(f"epoch: {i}, weights: {self.weights}, bias: {self.bias}")
        print(f"Final values: weights: {self.weights}, bias: {self.bias}\n")


    def compute_gradients(self, x, y_true, y_pred):
        difference =  y_pred - y_true
        gradient_b = np.mean(difference)
        gradients_w = np.matmul(x.transpose(), difference)
        gradients_w = np.array([np.mean(grad) for grad in gradients_w])
        return gradients_w, gradient_b


    def update_model_parameters(self, error_w, error_b, step_size_w=0.01, step_size_b=0.01):
        self.weights = self.weights - step_size_w * error_w
        self.bias = self.bias - step_size_b * error_b


    def predict(self, X):
        """
        Generates predictions
        
        Note: should be called after .fit()
        
        Args:
            X (array<m,n>): a matrix of floats with 
                m rows (#samples) and n columns (#features)
            
        Returns:
            A length m array of floats in the range [0, 1]
            with probability-like predictions
        """
        X_dot_weights = np.matmul(X, self.weights.transpose()) + self.bias
        probabilities = sigmoid(X_dot_weights)
        return np.array([1 if p > 0.5 else 0 for p in probabilities])



# --- Some utility functions 


def binary_accuracy(y_true, y_pred, threshold=0.5):
    """
    Computes binary classification accuracy
    
    Args:
        y_true (array<m>): m 0/1 floats with ground truth labels
        y_pred (array<m>): m [0,1] floats with "soft" predictions
        
    Returns:
        The average number of correct predictions
    """
    assert y_true.shape == y_pred.shape
    y_pred_thresholded = (y_pred >= threshold).astype(float)
    correct_predictions = y_pred_thresholded == y_true 
    return correct_predictions.mean()
    

def binary_cross_entropy(y_true, y_pred, eps=1e-15):
    """
    Computes binary cross entropy 
    
    Args:
        y_true (array<m>): m 0/1 floats with ground truth labels
        y_pred (array<m>): m [0,1] floats with "soft" predictions
        
    Returns:
        Binary cross entropy averaged over the input elements
    """
    assert y_true.shape == y_pred.shape
    y_pred = np.clip(y_pred, eps, 1 - eps)  # Avoid log(0)
    return - np.mean(
        y_true * np.log(y_pred) + 
        (1 - y_true) * (np.log(1 - y_pred))
    )


def sigmoid(x):
    """
    Applies the logistic function element-wise
    
    Hint: highly related to cross-entropy loss 
    
    Args:
        x (float or array): input to the logistic function
            the function is vectorized, so it is acceptible
            to pass an array of any shape.
    
    Returns:
        Element-wise sigmoid activations of the input 
    """
    return 1. / (1. + np.exp(-x))


def normalize_data(data):
    # Find the min and max values for X
    min_value = float('inf')
    max_value = float('-inf')
    for feature in data.columns[:2]:
        min_value = min(data[feature].min(), min_value)
        max_value = max(data[feature].max(), max_value)
    
    # apply normalization using found min and max values
    for feature in data.columns[:2]:
        data[feature] = data[feature].apply(lambda x: (x - min_value) / ((max_value - min_value)))

    return data

def add_feature(data):
    # add 3. feature "x2" as the product of x0, x1
    data['x2'] = data.apply(lambda row: (row['x0'] * row['x1']), axis=1)
    return data